﻿using System.Collections.Generic;

namespace Api.Models
{
    public class PhotoApiResponse : IApiResponse
    {
        private List<Photo> photos;

        public PhotoApiResponse(List<Photo> photos)
        {
            this.photos = photos;
        }

        public void Set(Integrator integrator)
        {
            integrator.Photos = photos;
        }
    }
}
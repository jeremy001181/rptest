﻿using Api.Controllers;

namespace Api.Models
{

    public interface IApiResponse
    {
        void Set(Integrator integrator);
    }
}
﻿using System.Collections.Generic;

namespace Api.Models
{

    public class AlbumApiResponse : IApiResponse
    {
        private List<Album> albums;

        public AlbumApiResponse(List<Album> albums)
        {
            this.albums = albums;
        }

        public void Set(Integrator integrator)
        {
            integrator.Albums = albums;
        }
    }
}